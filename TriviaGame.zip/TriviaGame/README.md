This project is a Trivia Quiz Game. The theme or category is Chemistry covering elements of the periodic table, and basic to intermediate level of information.

The player is given a set of 20 questions in sequence. Each question has 4 multiple choices with only one correct answer per question. However, each question is timed for 20seconds to answer before proceeding automatically to the next question. Answer all 20 questions to win the Trivia Quiz Game.

The project is an exercise on working with JQuery and Javascript, focusing on utilizing the timer function.