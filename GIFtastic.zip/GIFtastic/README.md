This project is a dynamic web page that populates with gifs and will be called GIFtastic. It uses GIPHY API to search for gifs.

The projects focuses on the use of JavaScript and jQuery to change the HTML and AJAX call to get a response from the API.