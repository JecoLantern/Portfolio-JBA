This project is a Role Playing Game. The theme is about Defense of the Ancients 2 (DOTA 2). It allows the user to pick a Hero and fight other Heroes with a click of the Attack button. The player will not have healing options. To win the game, defeat all the other Heroes with your chosen Hero.

The project is an exercise on working with JQuery and Javascript, focusing more with using JQuery.